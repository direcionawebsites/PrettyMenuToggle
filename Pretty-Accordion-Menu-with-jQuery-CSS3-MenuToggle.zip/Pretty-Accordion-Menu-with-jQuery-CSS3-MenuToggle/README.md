# MenuToggle
Simple Menu with toggle slide animation using jQuery and CSS.

Uses RetinaJS for better look on retina devices.

Animations and functionality coded by J Pazmino.
Look/color/design adapted from PSD seen at http://www.psdchat.com
